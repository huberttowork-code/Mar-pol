#!/usr/bin/env bash
# Skleja czesci szablonu i produkuje dwa pliki:
#
#   index.html               pelny dokument, do hostingu (Netlify, Vercel, zwykly serwer)
#   marpol-storefront.html   fragment bez <html> i <head>, pod hosting Artifacts
#
# Zdjecia trafiaja do dokumentu raz, w mapie base64 przypisywanej po wczytaniu DOM.
#
#   bash src/build.sh
#
set -e
cd "$(dirname "$0")"

FRAGMENT="../marpol-storefront.html"
PAGE="../index.html"
PLACEHOLDER='data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'

PARTS="01-head.html 02-home.css 03-views.css 04-home.html 05-catalog-product.html 06-b2b-footer.html 07-app.html"

cat $PARTS > .raw.html

# lista zdjec uzytych w markupie
grep -oE '__IMG:[A-Za-z0-9_]+__' .raw.html | sort -u | sed 's/__IMG://;s/__$//' > .keys.txt

# base64 generowane z img/, cache w .b64/
mkdir -p .b64
while read -r k; do
  [ -z "$k" ] && continue
  if [ ! -f "img/$k.jpg" ]; then echo "BRAK PLIKU: img/$k.jpg" >&2; exit 1; fi
  if [ ! -f ".b64/$k.txt" ] || [ "img/$k.jpg" -nt ".b64/$k.txt" ]; then
    printf 'data:image/jpeg;base64,' > ".b64/$k.txt"
    base64 -w0 "img/$k.jpg" >> ".b64/$k.txt"
  fi
done < .keys.txt

# w markupie zostaje sam klucz plus przezroczysty placeholder
sed -E "s|src=\"__IMG:([A-Za-z0-9_]+)__\"|data-img=\"\1\" src=\"$PLACEHOLDER\"|g" .raw.html > .body.html

{
  printf '<script>\n(function(){\nvar IMG={'
  first=1
  while read -r k; do
    [ -z "$k" ] && continue
    if [ $first -eq 0 ]; then printf ','; fi
    printf '"%s":"' "$k"
    tr -d '\n' < ".b64/$k.txt"
    printf '"'
    first=0
  done < .keys.txt
  printf '};\n'
  printf 'var n=document.querySelectorAll("img[data-img]");\n'
  printf 'for(var i=0;i<n.length;i++){var s=IMG[n[i].getAttribute("data-img")];if(s)n[i].src=s;}\n'
  printf '})();\n</script>\n'
} > .imgmap.js

# 1. fragment pod Artifacts
cat .body.html .imgmap.js > "$FRAGMENT"

# 2. pelny dokument pod zwykly hosting: style ida do <head>, reszta do <body>
{
  printf '<!doctype html>\n<html lang="pl">\n<head>\n'
  printf '<meta charset="utf-8">\n'
  printf '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
  printf '<meta name="description" content="Marpol Radom. Hurtownia tkanin, dzianin i dodatkow krawieckich dla szwalni i pracowni. Od 1993 roku.">\n'
  awk 'BEGIN{done=0} { if(!done && $0=="</style>"){ print "</style>"; print "</head>"; print "<body>"; done=1 } else print }' .body.html
  cat .imgmap.js
  printf '</body>\n</html>\n'
} > "$PAGE"

rm -f .raw.html .body.html .imgmap.js

LEFT=$(grep -c '__IMG:' "$PAGE" || true)
echo "index.html              $(wc -c < "$PAGE") bajtow"
echo "marpol-storefront.html  $(wc -c < "$FRAGMENT") bajtow"
echo "zdjec: $(wc -l < .keys.txt) / niepodmienione tokeny: $LEFT"
